/**
 * WAVE-PULSE AI // Master Application Orchestration & Event Controller
 */
document.addEventListener('DOMContentLoaded', () => {
    // 0. Register PWA Service Worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('./sw.js')
            .then(reg => console.log('Service Worker Registered:', reg.scope))
            .catch(err => console.error('Service Worker Error:', err));
    }

    // 1. Instantiate Core Canvas Renderers & Visualizers
    const satMap = new SatMapCanvas('sat-map-canvas', 'telemetry-tooltip');
    const spectrumVis = new SpectrumVisualizer('fft-canvas', 'waterfall-canvas');
    const hardware3D = new Hardware3DRenderer('hardware-3d-canvas');

    // 2. Projection Mode Toggle Buttons (3D Globe Mode vs 2D Flat View)
    const btnProjection3d = document.getElementById('btn-projection-3d');
    const btnProjection2d = document.getElementById('btn-projection-2d');
    const btnResetView = document.getElementById('btn-reset-view');

    if (btnProjection3d && btnProjection2d) {
        btnProjection3d.addEventListener('click', () => {
            satMap.setProjectionMode('3d');
            btnProjection3d.classList.add('active');
            btnProjection2d.classList.remove('active');
            logEvent('Switched Map to Interactive 3D Globe Projection Mode.');
        });

        btnProjection2d.addEventListener('click', () => {
            satMap.setProjectionMode('2d');
            btnProjection2d.classList.add('active');
            btnProjection3d.classList.remove('active');
            logEvent('Switched Map to 2D Equirectangular Flat Projection View.');
        });
    }

    if (btnResetView) {
        btnResetView.addEventListener('click', () => {
            satMap.cameraYaw = 0.4;
            satMap.cameraPitch = 0.3;
            logEvent('Reset Map Camera & View Rotation.');
        });
    }

    // 3. AI Model & Hardware Prototype Inspector Modal Controls
    const modelModal = document.getElementById('model-modal');
    const btnOpenModelInspector = document.getElementById('btn-open-model-inspector');
    const btnCloseModal = document.getElementById('btn-close-modal');

    if (btnOpenModelInspector) {
        btnOpenModelInspector.addEventListener('click', () => {
            modelModal.classList.remove('hidden');
            hardware3D.resize();
        });
    }

    if (btnCloseModal) {
        btnCloseModal.addEventListener('click', () => modelModal.classList.add('hidden'));
    }

    // Prototype 3D Tabs Switcher
    document.querySelectorAll('.prototype-tabs .proto-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.prototype-tabs .proto-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const protoType = tab.getAttribute('data-proto');
            hardware3D.setPrototype(protoType);
        });
    });

    // AI Model Hyperparameter Slider
    const sliderAiSensitivity = document.getElementById('slider-ai-sensitivity');
    const dispAiSensitivity = document.getElementById('disp-ai-sensitivity');
    if (sliderAiSensitivity) {
        sliderAiSensitivity.addEventListener('input', (e) => {
            dispAiSensitivity.textContent = parseFloat(e.target.value).toFixed(2);
        });
    }

    // PWA & Export Event Handlers
    let deferredPrompt = null;
    const btnInstallPwa = document.getElementById('btn-install-pwa');
    const btnSidebarInstall = document.getElementById('btn-sidebar-install');
    const btnExportJson = document.getElementById('btn-export-json');

    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        if (btnInstallPwa) btnInstallPwa.classList.remove('hidden');
    });

    function triggerPwaInstall() {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === 'accepted') {
                    logEvent('PWA Standalone App Installed successfully!');
                }
                deferredPrompt = null;
                if (btnInstallPwa) btnInstallPwa.classList.add('hidden');
            });
        } else {
            alert('To install as an app: Click your browser address bar menu (or Chrome 3 dots) and select "Install WavePulse AI" / "Add to Home Screen".');
        }
    }

    if (btnInstallPwa) btnInstallPwa.addEventListener('click', triggerPwaInstall);
    if (btnSidebarInstall) btnSidebarInstall.addEventListener('click', triggerPwaInstall);

    if (btnExportJson) {
        btnExportJson.addEventListener('click', () => {
            const exportData = {
                timestamp: new Date().toISOString(),
                constellation: {
                    activeNodes: satMap.satellites.length,
                    altitudeKm: satMap.altitudeKm,
                    inclinationDeg: satMap.inclinationDeg,
                    beamAngleDeg: satMap.beamAngleDeg
                },
                sensors: satMap.sensors,
                selectedSensor: satMap.selectedSensor
            };

            const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(exportData, null, 2));
            const downloadAnchor = document.createElement('a');
            downloadAnchor.setAttribute("href", dataStr);
            downloadAnchor.setAttribute("download", `wavepulse-ai-telemetry-${Date.now()}.json`);
            document.body.appendChild(downloadAnchor);
            downloadAnchor.click();
            downloadAnchor.remove();

            logEvent('Exported Sensor Network Telemetry JSON Data.');
        });
    }

    // 4. Audio Sonification Engine (Web Audio API)
    let audioCtx = null;
    let audioEnabled = false;
    let synthOsc = null;
    let synthGain = null;

    function initAudio() {
        if (!audioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            audioCtx = new AudioContext();
            synthOsc = audioCtx.createOscillator();
            synthGain = audioCtx.createGain();

            synthOsc.type = 'sine';
            synthOsc.frequency.value = 180;
            synthGain.gain.value = 0.05;

            synthOsc.connect(synthGain);
            synthGain.connect(audioCtx.destination);
            synthOsc.start();
        }
    }

    function toggleAudio() {
        if (!audioCtx) initAudio();
        audioEnabled = !audioEnabled;
        const icon = document.getElementById('icon-audio');

        if (audioEnabled) {
            audioCtx.resume();
            synthGain.gain.setValueAtTime(0.05, audioCtx.currentTime);
            icon.setAttribute('data-lucide', 'volume-2');
        } else {
            synthGain.gain.setValueAtTime(0.001, audioCtx.currentTime);
            icon.setAttribute('data-lucide', 'volume-x');
        }
        if (window.lucide) lucide.createIcons();
    }

    // 5. UI Slider & Band Controls
    const sliderAltitude = document.getElementById('slider-altitude');
    const sliderInclination = document.getElementById('slider-inclination');
    const sliderBeamAngle = document.getElementById('slider-beam-angle');

    const dispAltitude = document.getElementById('disp-altitude');
    const dispInclination = document.getElementById('disp-inclination');
    const dispBeamAngle = document.getElementById('disp-beam-angle');

    const selectSatBand = document.getElementById('select-sat-band');

    const chkFootprints = document.getElementById('chk-coverage-footprints');
    const chkBeams = document.getElementById('chk-link-beams');
    const chkHeatmap = document.getElementById('chk-heatmap');

    const btnTriggerAnomaly = document.getElementById('btn-trigger-anomaly');
    const btnToggleAudio = document.getElementById('btn-toggle-audio');

    const eventLogContainer = document.getElementById('event-log');

    // Telemetry Display Targets
    const valTotalCoverage = document.getElementById('val-total-coverage');
    const valAvgLatency = document.getElementById('val-avg-latency');
    const valAiStatus = document.getElementById('val-ai-status');

    const valPathLoss = document.getElementById('val-path-loss');
    const valSnr = document.getElementById('val-snr');
    const valThroughput = document.getElementById('val-throughput');

    // AI Prediction Elements
    const aiConfidence = document.getElementById('ai-confidence');
    const aiSignalName = document.getElementById('ai-signal-name');
    const aiSeverityVal = document.getElementById('ai-severity-val');
    const aiSeverityBar = document.getElementById('ai-severity-bar');

    // Inspector Elements
    const inspId = document.getElementById('insp-id');
    const inspType = document.getElementById('insp-type');
    const inspSat = document.getElementById('insp-sat');
    const inspFreq = document.getElementById('insp-freq');
    const inspAmp = document.getElementById('insp-amp');

    // Register Sliders
    sliderAltitude.addEventListener('input', (e) => {
        const val = parseInt(e.target.value);
        dispAltitude.textContent = `${val} km (${val < 700 ? 'LEO' : 'MEO'})`;
        satMap.altitudeKm = val;
    });

    sliderInclination.addEventListener('input', (e) => {
        const val = parseInt(e.target.value);
        dispInclination.textContent = `${val}° Polar/Equatorial`;
        satMap.inclinationDeg = val;
    });

    sliderBeamAngle.addEventListener('input', (e) => {
        const val = parseInt(e.target.value);
        dispBeamAngle.textContent = `${val}° Half-Angle`;
        satMap.beamAngleDeg = val;
    });

    chkFootprints.addEventListener('change', (e) => satMap.showFootprints = e.target.checked);
    chkBeams.addEventListener('change', (e) => satMap.showBeams = e.target.checked);
    chkHeatmap.addEventListener('change', (e) => satMap.showHeatmap = e.target.checked);

    // Sensor Mode Selector
    document.querySelectorAll('.sensor-mode-selector .mode-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.sensor-mode-selector .mode-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            satMap.activeSensorMode = btn.getAttribute('data-sensor-type');
        });
    });

    // Wave Frequency Band Tabs
    document.querySelectorAll('.band-tabs .band-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.band-tabs .band-tab').forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            const bandKey = tab.getAttribute('data-band');
            SignalSim.setBand(bandKey);

            const bandInfo = SignalSim.getBand();
            document.getElementById('disp-center-freq').textContent = `Center: ${(bandInfo.minFreq + bandInfo.maxFreq) / 2} ${bandInfo.unit}`;
            logEvent(`Switched Wave Analyzer Band to ${bandInfo.name}`);
        });
    });

    // Anomaly Trigger & Audio
    btnTriggerAnomaly.addEventListener('click', () => {
        const anomalyTypes = ['tsunami', 'seismic', 'jamming'];
        const chosen = anomalyTypes[Math.floor(Math.random() * anomalyTypes.length)];
        SignalSim.triggerAnomaly(chosen);
        logEvent(`TEST ANOMALY INJECTED: [${chosen.toUpperCase()}] Wave Pattern!`, 'alarm');
    });

    btnToggleAudio.addEventListener('click', toggleAudio);

    satMap.onSensorSelected = (sensor) => updateSensorInspector(sensor);
    satMap.onSensorDeployed = (sensor) => {
        logEvent(`Deployed New Sensor Node: ${sensor.id} (${sensor.lat}°, ${sensor.lon}°)`);
        updateSensorInspector(sensor);
    };

    function updateSensorInspector(sensor) {
        inspId.textContent = sensor.id;
        inspType.textContent = sensor.type === 'buoy' ? 'Hydro-Acoustic Buoy' : (sensor.type === 'seismic' ? 'Seismic Array' : 'RF Scatter Radar');
        inspSat.textContent = sensor.nearestSat ? `${sensor.nearestSat.id} (Linked)` : 'Searching Sat Beam...';
        inspFreq.textContent = sensor.freq;
        inspAmp.textContent = sensor.amp;
    }

    function logEvent(msg, type = 'normal') {
        const entry = document.createElement('div');
        entry.className = `log-entry ${type}`;

        const now = new Date();
        const timeStr = now.toTimeString().split(' ')[0] + '.' + String(now.getMilliseconds()).padStart(3, '0');

        entry.innerHTML = `
            <span class="log-time">${timeStr}</span>
            <span class="log-msg">${msg}</span>
        `;

        eventLogContainer.insertBefore(entry, eventLogContainer.firstChild);

        while (eventLogContainer.children.length > 20) {
            eventLogContainer.removeChild(eventLogContainer.lastChild);
        }
    }

    // Initial Event Logs
    logEvent('WAVE-PULSE AI System Initialized.');
    logEvent('Interactive 3D Globe Projection Engine Active.');
    logEvent('LEO Satellite Constellation Ground Tracks Locked.');

    // 6. Main Simulation Loop (60 FPS)
    let lastTime = performance.now();

    function frameLoop(now) {
        const dt = (now - lastTime) / 1000;
        lastTime = now;

        // 1. Update Sim Modules
        satMap.update(dt);
        SignalSim.update(dt);
        if (!modelModal.classList.contains('hidden')) {
            hardware3D.update(dt);
            hardware3D.render();
        }

        // 2. Compute Coverage Area Statistics
        const covRadiusKm = SatPhysics.getCoverageRadius(satMap.altitudeKm, satMap.beamAngleDeg);
        const footprintKm2 = SatPhysics.getFootprintAreaKm2(covRadiusKm);
        const totalCoverageKm2 = (footprintKm2 * satMap.satellites.length * 0.72) / 1e6;

        valTotalCoverage.textContent = `${totalCoverageKm2.toFixed(1)} Million km²`;

        if (satMap.selectedSensor && satMap.selectedSensor.nearestSat) {
            const sat = satMap.selectedSensor.nearestSat;
            const distKm = SatPhysics.getSlantRangeKm(sat.lat, sat.lon, sat.altKm, satMap.selectedSensor.lat, satMap.selectedSensor.lon);
            const budget = SatPhysics.computeLinkBudget(distKm, selectSatBand.value);

            valPathLoss.textContent = `${budget.pathLossDb} dB`;
            valSnr.textContent = `+${budget.snrDb} dB`;
            valThroughput.textContent = `${budget.throughputGbps} Gbps`;
            valAvgLatency.textContent = `${budget.latencyMs} ms`;
        }

        // 3. Render Canvas Views
        satMap.render();

        const timeSec = now / 1000;
        const spectrum = SignalSim.getFFTSpectrum(timeSec);
        spectrumVis.render(spectrum);

        // 4. Update AI Neural Signal Classifier
        const aiResult = AIClassifier.classifySpectrum(spectrum, SignalSim.isAnomalyActive(), SignalSim.getAnomalyType());

        aiConfidence.textContent = aiResult.confidence;
        aiSignalName.textContent = aiResult.classification;
        aiSeverityVal.textContent = `${aiResult.severityVal} (${aiResult.statusBadge})`;
        aiSeverityBar.style.width = aiResult.severityPct;

        valAiStatus.textContent = aiResult.statusBadge;
        valAiStatus.className = `telemetry-badge ${aiResult.statusClass}`;

        if (audioEnabled && synthOsc) {
            const freqHz = 120 + parseFloat(aiResult.severityVal) * 300;
            synthOsc.frequency.setTargetAtTime(freqHz, audioCtx.currentTime, 0.1);
        }

        requestAnimationFrame(frameLoop);
    }

    requestAnimationFrame(frameLoop);
});

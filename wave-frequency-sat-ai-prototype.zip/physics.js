/**
 * WAVE-PULSE AI // Satellite Orbit & Link Budget Kinematics
 */
const SatPhysics = (function () {
    const EARTH_RADIUS_KM = 6371; // Earth Mean Radius
    const SPEED_OF_LIGHT_MS = 299792458; // m/s

    /**
     * Calculates coverage footprint radius on Earth surface in kilometers
     * @param {number} altitudeKm Satellite altitude above Earth surface (km)
     * @param {number} halfBeamAngleDeg Half beam angle in degrees
     * @returns {number} Radius of coverage circle on Earth surface (km)
     */
    function getCoverageRadius(altitudeKm, halfBeamAngleDeg) {
        const theta = (halfBeamAngleDeg * Math.PI) / 180;
        // Central angle gamma from Earth center
        const sinGamma = (EARTH_RADIUS_KM + altitudeKm) / EARTH_RADIUS_KM * Math.sin(theta);
        const gamma = Math.asin(Math.min(1, Math.max(-1, sinGamma))) - theta;
        return Math.max(100, EARTH_RADIUS_KM * Math.max(0, gamma));
    }

    /**
     * Calculates total coverage area of a single satellite footprint in km²
     * @param {number} radiusKm Radius of footprint circle (km)
     * @returns {number} Area in km²
     */
    function getFootprintAreaKm2(radiusKm) {
        const theta = radiusKm / EARTH_RADIUS_KM;
        return 2 * Math.PI * Math.pow(EARTH_RADIUS_KM, 2) * (1 - Math.cos(theta));
    }

    /**
     * Calculates distance (slant range) between Satellite and Ground Sensor
     * @param {number} lat1 Sat Lat
     * @param {number} lon1 Sat Lon
     * @param {number} alt1 Sat Altitude (km)
     * @param {number} lat2 Sensor Lat
     * @param {number} lon2 Sensor Lon
     * @returns {number} Slant Range in kilometers
     */
    function getSlantRangeKm(lat1, lon1, alt1, lat2, lon2) {
        const r1 = EARTH_RADIUS_KM + alt1;
        const r2 = EARTH_RADIUS_KM;

        const phi1 = (lat1 * Math.PI) / 180;
        const phi2 = (lat2 * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;

        const cosGamma = Math.sin(phi1) * Math.sin(phi2) + Math.cos(phi1) * Math.cos(phi2) * Math.cos(dLon);
        
        // Law of cosines in 3D triangle
        const slantRange2 = r1 * r1 + r2 * r2 - 2 * r1 * r2 * cosGamma;
        return Math.sqrt(Math.max(0, slantRange2));
    }

    /**
     * Compute Link Budget Metrics (Path Loss, SNR, Latency)
     * @param {number} distanceKm Slant range distance in km
     * @param {string} band Ka, Ku, or S
     * @returns {object} { pathLossDb, snrDb, latencyMs, throughputGbps }
     */
    function computeLinkBudget(distanceKm, band) {
        let freqGhz = 30; // Default Ka
        let txPowerDbw = 20;

        if (band === 'Ku') {
            freqGhz = 14;
            txPowerDbw = 18;
        } else if (band === 'S') {
            freqGhz = 3;
            txPowerDbw = 15;
        }

        // Free Space Path Loss: FSPL(dB) = 92.45 + 20*log10(d_km) + 20*log10(f_GHz)
        const fsplDb = 92.45 + 20 * Math.log10(Math.max(1, distanceKm)) + 20 * Math.log10(freqGhz);
        
        // Thermal Noise + Antenna Gains simulation
        const noiseDb = -110; 
        const snrDb = txPowerDbw + 45 - fsplDb - noiseDb;
        
        // One-way propagation latency in ms
        const latencyMs = (distanceKm * 1000) / (SPEED_OF_LIGHT_MS / 1000);

        // Shannon Capacity estimation for throughput
        const bandwidthMhz = band === 'Ka' ? 500 : (band === 'Ku' ? 250 : 50);
        const snrLinear = Math.pow(10, Math.max(0.1, snrDb) / 10);
        const throughputGbps = (bandwidthMhz * Math.log2(1 + snrLinear)) / 1000;

        return {
            pathLossDb: -fsplDb.toFixed(1),
            snrDb: snrDb.toFixed(1),
            latencyMs: latencyMs.toFixed(1),
            throughputGbps: throughputGbps.toFixed(2)
        };
    }

    return {
        EARTH_RADIUS_KM,
        getCoverageRadius,
        getFootprintAreaKm2,
        getSlantRangeKm,
        computeLinkBudget
    };
})();

/**
 * WAVE-PULSE AI // FFT Spectrum & Waterfall Spectrogram Renderer
 */
class SpectrumVisualizer {
    constructor(fftCanvasId, waterfallCanvasId) {
        this.fftCanvas = document.getElementById(fftCanvasId);
        this.fftCtx = this.fftCanvas.getContext('2d');

        this.wfCanvas = document.getElementById(waterfallCanvasId);
        this.wfCtx = this.wfCanvas.getContext('2d');

        // Waterfall History Buffer (Offscreen canvas for smooth scrolling)
        this.wfOffscreen = document.createElement('canvas');
        this.wfOffCtx = this.wfOffscreen.getContext('2d');

        this.width = 0;
        this.height = 0;

        this.resize();
        window.addEventListener('resize', () => this.resize());
    }

    resize() {
        const dpr = window.devicePixelRatio || 1;

        // FFT Canvas Resize
        const fftRect = this.fftCanvas.parentElement.getBoundingClientRect();
        this.width = fftRect.width - 16;
        this.height = 110;

        this.fftCanvas.width = this.width * dpr;
        this.fftCanvas.height = this.height * dpr;
        this.fftCtx.scale(dpr, dpr);

        // Waterfall Canvas Resize
        const wfRect = this.wfCanvas.parentElement.getBoundingClientRect();
        this.wfCanvas.width = this.width * dpr;
        this.wfCanvas.height = this.height * dpr;
        this.wfCtx.scale(dpr, dpr);

        this.wfOffscreen.width = this.width;
        this.wfOffscreen.height = this.height;
    }

    /**
     * Render live FFT Bar Chart and update Waterfall Spectrogram
     * @param {Float32Array} spectrum Magnitude array (64 bins)
     */
    render(spectrum) {
        this.renderFFT(spectrum);
        this.renderWaterfall(spectrum);
    }

    renderFFT(spectrum) {
        const ctx = this.fftCtx;
        const width = this.width;
        const height = this.height;

        ctx.clearRect(0, 0, width, height);

        const numBins = spectrum.length;
        const barWidth = width / numBins;

        for (let i = 0; i < numBins; i++) {
            const mag = spectrum[i];
            const barHeight = Math.min(height, (mag / 2.5) * height);
            const x = i * barWidth;
            const y = height - barHeight;

            // Spectral Gradient (Cyan to Purple to Amber)
            const grad = ctx.createLinearGradient(0, height, 0, 0);
            grad.addColorStop(0, '#00f3ff');
            grad.addColorStop(0.6, '#a855f7');
            grad.addColorStop(1, '#f59e0b');

            ctx.fillStyle = grad;
            ctx.fillRect(x, y, barWidth - 1, barHeight);
        }
    }

    renderWaterfall(spectrum) {
        const offCtx = this.wfOffCtx;
        const width = this.width;
        const height = this.height;

        // Shift old waterfall down by 2 pixels
        offCtx.drawImage(this.wfOffscreen, 0, 0, width, height, 0, 2, width, height);

        // Draw new 2px row at the top
        const numBins = spectrum.length;
        const binWidth = width / numBins;

        for (let i = 0; i < numBins; i++) {
            const mag = spectrum[i];
            const val = Math.min(1, mag / 2.2);

            // False-color thermal colormap (Dark Blue -> Cyan -> Purple -> Yellow -> Red)
            let r = 0, g = 0, b = 0;
            if (val < 0.2) {
                b = Math.round(val * 5 * 255);
            } else if (val < 0.5) {
                g = Math.round((val - 0.2) * 3.33 * 255);
                b = 255;
            } else if (val < 0.8) {
                r = Math.round((val - 0.5) * 3.33 * 255);
                g = 255;
                b = Math.round((0.8 - val) * 3.33 * 255);
            } else {
                r = 255;
                g = Math.round((1 - val) * 5 * 255);
                b = 0;
            }

            offCtx.fillStyle = `rgb(${r}, ${g}, ${b})`;
            offCtx.fillRect(i * binWidth, 0, binWidth + 0.5, 2);
        }

        // Blit offscreen buffer to display canvas
        this.wfCtx.clearRect(0, 0, width, height);
        this.wfCtx.drawImage(this.wfOffscreen, 0, 0);
    }
}

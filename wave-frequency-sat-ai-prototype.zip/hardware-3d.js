/**
 * WAVE-PULSE AI // 3D Hardware Prototype Wireframe Canvas Renderer
 */
class Hardware3DRenderer {
    constructor(canvasId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');

        this.currentProto = 'sat'; // 'sat' or 'buoy'
        this.rotX = 0.3;
        this.rotY = 0.5;
        this.rotZ = 0;

        this.width = 0;
        this.height = 0;

        this.resize();
        window.addEventListener('resize', () => this.resize());
    }

    resize() {
        const dpr = window.devicePixelRatio || 1;
        const rect = this.canvas.parentElement.getBoundingClientRect();
        this.width = rect.width;
        this.height = 220;

        this.canvas.width = this.width * dpr;
        this.canvas.height = this.height * dpr;
        this.ctx.scale(dpr, dpr);
    }

    setPrototype(type) {
        this.currentProto = type;
        const caption = document.getElementById('proto-caption');
        if (type === 'sat') {
            caption.innerHTML = '<strong>LEO Satellite Payload</strong>: Ka-Band Phased Array Beamformer + Onboard Edge AI Neural Accelerator.';
        } else {
            caption.innerHTML = '<strong>AI Ocean Buoy Node</strong>: Sub-surface Hydroacoustic Transducer Array + Satcom Uplink Dome.';
        }
    }

    update(dt) {
        this.rotY += dt * 0.8;
        this.rotX += dt * 0.2;
    }

    // 3D Point Rotation & Perspective Projection
    project(x, y, z) {
        // Rotate Y
        let x1 = x * Math.cos(this.rotY) - z * Math.sin(this.rotY);
        let z1 = x * Math.sin(this.rotY) + z * Math.cos(this.rotY);

        // Rotate X
        let y2 = y * Math.cos(this.rotX) - z1 * Math.sin(this.rotX);
        let z2 = y * Math.sin(this.rotX) + z1 * Math.cos(this.rotX);

        // Distance & Scale
        const fov = 280;
        const dist = 3.5;
        const scale = fov / (dist + z2);

        return {
            x: this.width / 2 + x1 * scale,
            y: this.height / 2 + y2 * scale
        };
    }

    render() {
        this.ctx.clearRect(0, 0, this.width, this.height);

        if (this.currentProto === 'sat') {
            this.renderSatelliteModel();
        } else {
            this.renderBuoyModel();
        }
    }

    renderSatelliteModel() {
        const ctx = this.ctx;

        // Satellite Main Bus Cube Vertices
        const vertices = [
            [-0.4, -0.4, -0.4], [0.4, -0.4, -0.4], [0.4, 0.4, -0.4], [-0.4, 0.4, -0.4],
            [-0.4, -0.4, 0.4],  [0.4, -0.4, 0.4],  [0.4, 0.4, 0.4],  [-0.4, 0.4, 0.4]
        ];

        const edges = [
            [0,1],[1,2],[2,3],[3,0],
            [4,5],[5,6],[6,7],[7,4],
            [0,4],[1,5],[2,6],[3,7]
        ];

        // Draw Cube Edges
        ctx.strokeStyle = '#00f3ff';
        ctx.lineWidth = 1.8;

        edges.forEach(([i, j]) => {
            const p1 = this.project(...vertices[i]);
            const p2 = this.project(...vertices[j]);
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
        });

        // Solar Array Wings (Left & Right)
        const leftWing = [[-0.4,0,0], [-1.4,0,-0.2], [-1.4,0,0.2], [-0.4,0,0]];
        const rightWing = [[0.4,0,0], [1.4,0,-0.2], [1.4,0,0.2], [0.4,0,0]];

        ctx.strokeStyle = '#a855f7';
        ctx.lineWidth = 1.4;
        this.drawPoly(leftWing);
        this.drawPoly(rightWing);

        // Phased Array Antenna Dish
        const dishCenter = this.project(0, 0.4, 0);
        ctx.fillStyle = 'rgba(16, 185, 129, 0.3)';
        ctx.strokeStyle = '#10b981';
        ctx.beginPath();
        ctx.arc(dishCenter.x, dishCenter.y + 15, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
    }

    renderBuoyModel() {
        const ctx = this.ctx;

        // Buoy Float Ring Ring Circles
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 1.8;

        for (let a = 0; a < Math.PI * 2; a += Math.PI / 8) {
            const x = Math.cos(a) * 0.8;
            const z = Math.sin(a) * 0.8;
            const p = this.project(x, 0, z);

            ctx.beginPath();
            ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
            ctx.fillStyle = '#10b981';
            ctx.fill();
        }

        // Sub-surface Hydrophone Pole
        const topPole = this.project(0, -0.6, 0);
        const botPole = this.project(0, 1.2, 0);

        ctx.strokeStyle = '#00f3ff';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(topPole.x, topPole.y);
        ctx.lineTo(botPole.x, botPole.y);
        ctx.stroke();

        // Satcom Dome Top
        const domePos = this.project(0, -0.6, 0);
        ctx.fillStyle = 'rgba(168, 85, 247, 0.4)';
        ctx.strokeStyle = '#a855f7';
        ctx.beginPath();
        ctx.arc(domePos.x, domePos.y, 14, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
    }

    drawPoly(pts) {
        const ctx = this.ctx;
        ctx.beginPath();
        pts.forEach((pt, i) => {
            const p = this.project(...pt);
            if (i === 0) ctx.moveTo(p.x, p.y);
            else ctx.lineTo(p.x, p.y);
        });
        ctx.closePath();
        ctx.stroke();
    }
}

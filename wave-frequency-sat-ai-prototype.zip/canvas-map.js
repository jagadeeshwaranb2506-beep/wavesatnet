/**
 * WAVE-PULSE AI // High-Performance Global Satellite Map (2D & 3D Interactive Globe)
 */
class SatMapCanvas {
    constructor(canvasId, tooltipId) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.tooltip = document.getElementById(tooltipId);

        this.width = 0;
        this.height = 0;

        // Projection Mode: '2d' or '3d'
        this.projectionMode = '3d'; // Default to 3D Globe Mode

        // 3D Camera Controls
        this.cameraYaw = 0.4;
        this.cameraPitch = 0.3;
        this.isDragging = false;
        this.lastMouseX = 0;
        this.lastMouseY = 0;

        // Interactive Options
        this.showFootprints = true;
        this.showBeams = true;
        this.showHeatmap = true;
        this.activeSensorMode = 'buoy';

        // Constellation State (16 Satellites)
        this.altitudeKm = 550;
        this.inclinationDeg = 53;
        this.beamAngleDeg = 45;
        this.satellites = [];
        
        // Deployed AI Wave Sensor Nodes
        this.sensors = [];
        this.selectedSensor = null;

        this.hoveredObject = null;
        this.time = 0;

        this.initConstellation();
        this.initDefaultSensors();
        this.setupEvents();
        this.resize();
    }

    initConstellation() {
        this.satellites = [];
        const numPlanes = 4;
        const satsPerPlane = 4;

        for (let p = 0; p < numPlanes; p++) {
            const raan = (p * (360 / numPlanes));
            for (let s = 0; s < satsPerPlane; s++) {
                const meanAnomaly = (s * (360 / satsPerPlane) + p * 22.5) % 360;
                this.satellites.push({
                    id: `SAT-${String(p * satsPerPlane + s + 1).padStart(2, '0')}`,
                    plane: p,
                    raan: raan,
                    meanAnomaly: meanAnomaly,
                    lat: 0,
                    lon: 0,
                    altKm: this.altitudeKm,
                    connectedSensors: 0
                });
            }
        }
    }

    initDefaultSensors() {
        this.sensors = [
            { id: 'BUOY-PACIFIC-01', type: 'buoy', lat: 15.4, lon: -145.2, name: 'Pacific Deep Swell Array', freq: '0.18 Hz', amp: '2.1m' },
            { id: 'BUOY-ATLANTIC-02', type: 'buoy', lat: 32.1, lon: -64.8, name: 'Bermuda Hydro-Acoustic Buoy', freq: '0.24 Hz', amp: '1.4m' },
            { id: 'SEISMIC-RING-01', type: 'seismic', lat: -8.5, lon: 115.2, name: 'Java Trench Microseism Node', freq: '18.4 Hz', amp: '0.04m' },
            { id: 'SEISMIC-ALASKA-02', type: 'seismic', lat: 58.3, lon: -134.4, name: 'Aleutian Sub-Surface Array', freq: '24.1 Hz', amp: '0.08m' },
            { id: 'RF-HAWAII-01', type: 'rf', lat: 21.3, lon: -157.8, name: 'Honolulu Scatter Radar', freq: '4.8 MHz', amp: '12.5 dB' },
            { id: 'BUOY-INDIAN-03', type: 'buoy', lat: -12.0, lon: 75.0, name: 'Mid-Indian Ridge Swell Sensor', freq: '0.15 Hz', amp: '1.9m' }
        ];
        this.selectedSensor = this.sensors[0];
    }

    resize() {
        const rect = this.canvas.parentElement.getBoundingClientRect();
        this.width = rect.width;
        this.height = rect.height;

        const dpr = window.devicePixelRatio || 1;
        this.canvas.width = this.width * dpr;
        this.canvas.height = this.height * dpr;
        this.ctx.scale(dpr, dpr);
    }

    setProjectionMode(mode) {
        this.projectionMode = mode;
    }

    // 2D Equirectangular Mapping
    latLonToXY2D(lat, lon) {
        const x = ((lon + 180) / 360) * this.width;
        const y = ((90 - lat) / 180) * this.height;
        return { x, y, visible: true };
    }

    xyToLatLon2D(x, y) {
        const lon = (x / this.width) * 360 - 180;
        const lat = 90 - (y / this.height) * 180;
        return { lat: parseFloat(lat.toFixed(2)), lon: parseFloat(lon.toFixed(2)) };
    }

    // 3D Sphere Projection Mapping
    latLonTo3D(lat, lon, altKm = 0) {
        const radius = Math.min(this.width, this.height) * 0.36;
        const r = radius * (1 + altKm / 12000);

        const phi = (lat * Math.PI) / 180;
        const theta = (lon * Math.PI) / 180;

        // 3D Unit Coordinates
        let x = r * Math.cos(phi) * Math.sin(theta);
        let y = -r * Math.sin(phi);
        let z = r * Math.cos(phi) * Math.cos(theta);

        // Apply Yaw (Y-axis) and Pitch (X-axis) Rotations
        const yaw = this.cameraYaw + (this.projectionMode === '3d' ? this.time * 0.08 : 0);
        const pitch = this.cameraPitch;

        // Rotate Y
        let x1 = x * Math.cos(yaw) + z * Math.sin(yaw);
        let z1 = -x * Math.sin(yaw) + z * Math.cos(yaw);

        // Rotate X
        let y2 = y * Math.cos(pitch) - z1 * Math.sin(pitch);
        let z2 = y * Math.sin(pitch) + z1 * Math.cos(pitch);

        const centerX = this.width / 2;
        const centerY = this.height / 2;

        return {
            x: centerX + x1,
            y: centerY + y2,
            z: z2,
            visible: z2 > -radius * 0.2 // Visible if front-facing
        };
    }

    latLonToXY(lat, lon, altKm = 0) {
        if (this.projectionMode === '2d') {
            return this.latLonToXY2D(lat, lon);
        } else {
            return this.latLonTo3D(lat, lon, altKm);
        }
    }

    update(dt) {
        this.time += dt;
        const orbitalPeriodSec = 90;
        const angularVelocity = (360 / orbitalPeriodSec) * dt;

        this.satellites.forEach(sat => {
            sat.meanAnomaly = (sat.meanAnomaly + angularVelocity) % 360;
            const incRad = (this.inclinationDeg * Math.PI) / 180;
            const u = ((sat.meanAnomaly + sat.raan) * Math.PI) / 180;

            const latRad = Math.asin(Math.sin(incRad) * Math.sin(u));
            const lonRad = Math.atan2(Math.cos(incRad) * Math.sin(u), Math.cos(u)) + ((sat.raan - (this.time * 2)) * Math.PI / 180);

            sat.lat = (latRad * 180) / Math.PI;
            sat.lon = (((lonRad * 180) / Math.PI + 180) % 360) - 180;
            sat.altKm = this.altitudeKm;
            sat.connectedSensors = 0;
        });

        const covRadiusKm = SatPhysics.getCoverageRadius(this.altitudeKm, this.beamAngleDeg);

        this.sensors.forEach(sensor => {
            sensor.nearestSat = null;
            sensor.minDistKm = Infinity;

            this.satellites.forEach(sat => {
                const distKm = SatPhysics.getSlantRangeKm(sat.lat, sat.lon, sat.altKm, sensor.lat, sensor.lon);
                if (distKm <= covRadiusKm) {
                    sat.connectedSensors++;
                    if (distKm < sensor.minDistKm) {
                        sensor.minDistKm = distKm;
                        sensor.nearestSat = sat;
                    }
                }
            });
        });
    }

    render() {
        this.ctx.clearRect(0, 0, this.width, this.height);

        if (this.projectionMode === '2d') {
            this.render2D();
        } else {
            this.render3D();
        }
    }

    // =========================================================================
    // 2D RENDER PIPELINE
    // =========================================================================
    render2D() {
        const ctx = this.ctx;
        ctx.fillStyle = '#060a17';
        ctx.fillRect(0, 0, this.width, this.height);

        // Lat/Lon Grid Lines
        ctx.strokeStyle = 'rgba(0, 243, 255, 0.06)';
        ctx.lineWidth = 1;

        for (let lat = -60; lat <= 60; lat += 30) {
            const { y } = this.latLonToXY2D(lat, 0);
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(this.width, y);
            ctx.stroke();
        }

        for (let lon = -150; lon <= 150; lon += 30) {
            const { x } = this.latLonToXY2D(0, lon);
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, this.height);
            ctx.stroke();
        }

        this.draw2DContinents();

        if (this.showHeatmap) this.drawHeatmap2D();
        if (this.showFootprints) this.drawFootprints2D();
        if (this.showBeams) this.drawBeams2D();

        this.drawSensors2D();
        this.drawSatellites2D();
    }

    draw2DContinents() {
        const ctx = this.ctx;
        ctx.fillStyle = 'rgba(15, 26, 48, 0.7)';
        ctx.strokeStyle = 'rgba(0, 243, 255, 0.25)';
        ctx.lineWidth = 1.2;

        const continents = [
            [[-168,65],[-140,70],[-120,75],[-80,72],[-60,45],[-75,30],[-105,20],[-120,35],[-168,65]],
            [[-80,10],[-50,-5],[-35,-15],[-60,-55],[-75,-45],[-80,10]],
            [[-10,36],[30,32],[40,70],[100,75],[170,65],[140,35],[100,10],[75,25],[35,40],[-10,36]],
            [[-15,35],[35,32],[50,12],[40,-35],[15,-35],[-15,10],[-15,35]],
            [[113,-12],[153,-15],[150,-38],[115,-35],[113,-12]]
        ];

        continents.forEach(poly => {
            ctx.beginPath();
            poly.forEach((pt, idx) => {
                const { x, y } = this.latLonToXY2D(pt[1], pt[0]);
                if (idx === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            });
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
        });
    }

    drawHeatmap2D() {
        const ctx = this.ctx;
        const covRadiusKm = SatPhysics.getCoverageRadius(this.altitudeKm, this.beamAngleDeg);
        const radiusPx = (covRadiusKm / 40000) * this.width * 0.9;

        this.satellites.forEach(sat => {
            const { x, y } = this.latLonToXY2D(sat.lat, sat.lon);
            const grad = ctx.createRadialGradient(x, y, 0, x, y, radiusPx);
            grad.addColorStop(0, 'rgba(0, 243, 255, 0.15)');
            grad.addColorStop(0.6, 'rgba(168, 85, 247, 0.08)');
            grad.addColorStop(1, 'rgba(0, 0, 0, 0)');

            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(x, y, radiusPx, 0, Math.PI * 2);
            ctx.fill();
        });
    }

    drawFootprints2D() {
        const ctx = this.ctx;
        const covRadiusKm = SatPhysics.getCoverageRadius(this.altitudeKm, this.beamAngleDeg);
        const radiusPx = (covRadiusKm / 40000) * this.width * 0.9;

        this.satellites.forEach(sat => {
            const { x, y } = this.latLonToXY2D(sat.lat, sat.lon);
            ctx.strokeStyle = 'rgba(0, 243, 255, 0.35)';
            ctx.lineWidth = 1.2;
            ctx.setLineDash([4, 4]);

            ctx.beginPath();
            ctx.arc(x, y, radiusPx, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);
        });
    }

    drawBeams2D() {
        const ctx = this.ctx;
        this.sensors.forEach(sensor => {
            if (sensor.nearestSat) {
                const sPos = this.latLonToXY2D(sensor.lat, sensor.lon);
                const satPos = this.latLonToXY2D(sensor.nearestSat.lat, sensor.nearestSat.lon);

                const grad = ctx.createLinearGradient(satPos.x, satPos.y, sPos.x, sPos.y);
                grad.addColorStop(0, 'rgba(0, 243, 255, 0.8)');
                grad.addColorStop(1, 'rgba(16, 185, 129, 0.8)');

                ctx.strokeStyle = grad;
                ctx.lineWidth = 1.8;
                ctx.beginPath();
                ctx.moveTo(satPos.x, satPos.y);
                ctx.lineTo(sPos.x, sPos.y);
                ctx.stroke();

                const progress = (this.time * 2) % 1;
                const px = satPos.x + (sPos.x - satPos.x) * progress;
                const py = satPos.y + (sPos.y - satPos.y) * progress;

                ctx.fillStyle = '#ffffff';
                ctx.beginPath();
                ctx.arc(px, py, 3, 0, Math.PI * 2);
                ctx.fill();
            }
        });
    }

    drawSensors2D() {
        const ctx = this.ctx;
        this.sensors.forEach(sensor => {
            const { x, y } = this.latLonToXY2D(sensor.lat, sensor.lon);
            const isSelected = this.selectedSensor && this.selectedSensor.id === sensor.id;

            let color = '#10b981';
            if (sensor.type === 'seismic') color = '#a855f7';
            else if (sensor.type === 'rf') color = '#f59e0b';

            const pulse = (Math.sin(this.time * 4) + 1) * 4;
            ctx.strokeStyle = color;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(x, y, 8 + pulse, 0, Math.PI * 2);
            ctx.stroke();

            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(x, y, isSelected ? 6 : 4, 0, Math.PI * 2);
            ctx.fill();

            if (isSelected) {
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(x, y, 10, 0, Math.PI * 2);
                ctx.stroke();
            }
        });
    }

    drawSatellites2D() {
        const ctx = this.ctx;
        this.satellites.forEach(sat => {
            const { x, y } = this.latLonToXY2D(sat.lat, sat.lon);

            ctx.fillStyle = 'rgba(0, 243, 255, 0.4)';
            ctx.beginPath();
            ctx.arc(x, y, 7, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#00f3ff';
            ctx.fillRect(x - 3, y - 3, 6, 6);

            ctx.fillStyle = '#ffffff';
            ctx.fillRect(x - 8, y - 1, 4, 2);
            ctx.fillRect(x + 4, y - 1, 4, 2);
        });
    }

    // =========================================================================
    // 3D GLOBE RENDER PIPELINE
    // =========================================================================
    render3D() {
        const ctx = this.ctx;
        const centerX = this.width / 2;
        const centerY = this.height / 2;
        const radius = Math.min(this.width, this.height) * 0.36;

        // Background Space & Stars
        ctx.fillStyle = '#030612';
        ctx.fillRect(0, 0, this.width, this.height);

        // Atmosphere Glow Rim
        const atmoGrad = ctx.createRadialGradient(centerX, centerY, radius * 0.95, centerX, centerY, radius * 1.15);
        atmoGrad.addColorStop(0, 'rgba(0, 243, 255, 0.35)');
        atmoGrad.addColorStop(0.5, 'rgba(168, 85, 247, 0.15)');
        atmoGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');

        ctx.fillStyle = atmoGrad;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius * 1.15, 0, Math.PI * 2);
        ctx.fill();

        // Globe Ocean Base Sphere
        ctx.fillStyle = '#070d1e';
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.fill();

        // 3D Latitude / Longitude Mesh Wireframe
        ctx.strokeStyle = 'rgba(0, 243, 255, 0.12)';
        ctx.lineWidth = 1;

        for (let lat = -60; lat <= 60; lat += 30) {
            ctx.beginPath();
            let first = true;
            for (let lon = -180; lon <= 180; lon += 10) {
                const pt = this.latLonTo3D(lat, lon, 0);
                if (pt.visible) {
                    if (first) { ctx.moveTo(pt.x, pt.y); first = false; }
                    else ctx.lineTo(pt.x, pt.y);
                } else {
                    first = true;
                }
            }
            ctx.stroke();
        }

        for (let lon = -180; lon < 180; lon += 30) {
            ctx.beginPath();
            let first = true;
            for (let lat = -90; lat <= 90; lat += 10) {
                const pt = this.latLonTo3D(lat, lon, 0);
                if (pt.visible) {
                    if (first) { ctx.moveTo(pt.x, pt.y); first = false; }
                    else ctx.lineTo(pt.x, pt.y);
                } else {
                    first = true;
                }
            }
            ctx.stroke();
        }

        // Render 3D Continents
        this.draw3DContinents();

        // Render 3D Beams
        if (this.showBeams) this.drawBeams3D();

        // Render 3D Sensors
        this.drawSensors3D();

        // Render 3D Satellites & Coverage Cones
        this.drawSatellites3D();

        // Globe Border Outline
        ctx.strokeStyle = 'rgba(0, 243, 255, 0.5)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();
    }

    draw3DContinents() {
        const ctx = this.ctx;
        ctx.fillStyle = 'rgba(15, 28, 52, 0.85)';
        ctx.strokeStyle = 'rgba(0, 243, 255, 0.35)';
        ctx.lineWidth = 1.2;

        const continents = [
            [[-168,65],[-140,70],[-120,75],[-80,72],[-60,45],[-75,30],[-105,20],[-120,35],[-168,65]],
            [[-80,10],[-50,-5],[-35,-15],[-60,-55],[-75,-45],[-80,10]],
            [[-10,36],[30,32],[40,70],[100,75],[170,65],[140,35],[100,10],[75,25],[35,40],[-10,36]],
            [[-15,35],[35,32],[50,12],[40,-35],[15,-35],[-15,10],[-15,35]],
            [[113,-12],[153,-15],[150,-38],[115,-35],[113,-12]]
        ];

        continents.forEach(poly => {
            ctx.beginPath();
            let visibleCount = 0;

            poly.forEach((pt, idx) => {
                const p = this.latLonTo3D(pt[1], pt[0], 0);
                if (p.visible) visibleCount++;
                if (idx === 0) ctx.moveTo(p.x, p.y);
                else ctx.lineTo(p.x, p.y);
            });

            ctx.closePath();
            if (visibleCount > 2) {
                ctx.fill();
                ctx.stroke();
            }
        });
    }

    drawBeams3D() {
        const ctx = this.ctx;
        this.sensors.forEach(sensor => {
            if (sensor.nearestSat) {
                const sPos = this.latLonTo3D(sensor.lat, sensor.lon, 0);
                const satPos = this.latLonTo3D(sensor.nearestSat.lat, sensor.nearestSat.lon, sensor.nearestSat.altKm);

                if (sPos.visible || satPos.visible) {
                    const grad = ctx.createLinearGradient(satPos.x, satPos.y, sPos.x, sPos.y);
                    grad.addColorStop(0, 'rgba(0, 243, 255, 0.9)');
                    grad.addColorStop(1, 'rgba(16, 185, 129, 0.9)');

                    ctx.strokeStyle = grad;
                    ctx.lineWidth = 1.8;
                    ctx.beginPath();
                    ctx.moveTo(satPos.x, satPos.y);
                    ctx.lineTo(sPos.x, sPos.y);
                    ctx.stroke();

                    const progress = (this.time * 2) % 1;
                    const px = satPos.x + (sPos.x - satPos.x) * progress;
                    const py = satPos.y + (sPos.y - satPos.y) * progress;

                    ctx.fillStyle = '#ffffff';
                    ctx.beginPath();
                    ctx.arc(px, py, 3, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
        });
    }

    drawSensors3D() {
        const ctx = this.ctx;
        this.sensors.forEach(sensor => {
            const p = this.latLonTo3D(sensor.lat, sensor.lon, 0);
            if (!p.visible) return;

            const isSelected = this.selectedSensor && this.selectedSensor.id === sensor.id;
            let color = '#10b981';
            if (sensor.type === 'seismic') color = '#a855f7';
            else if (sensor.type === 'rf') color = '#f59e0b';

            const pulse = (Math.sin(this.time * 4) + 1) * 4;
            ctx.strokeStyle = color;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(p.x, p.y, 7 + pulse, 0, Math.PI * 2);
            ctx.stroke();

            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, isSelected ? 6 : 4, 0, Math.PI * 2);
            ctx.fill();

            if (isSelected) {
                ctx.strokeStyle = '#ffffff';
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.arc(p.x, p.y, 9, 0, Math.PI * 2);
                ctx.stroke();
            }
        });
    }

    drawSatellites3D() {
        const ctx = this.ctx;
        const covRadiusKm = SatPhysics.getCoverageRadius(this.altitudeKm, this.beamAngleDeg);

        this.satellites.forEach(sat => {
            const satPos = this.latLonTo3D(sat.lat, sat.lon, sat.altKm);
            const groundPos = this.latLonTo3D(sat.lat, sat.lon, 0);

            if (!satPos.visible && !groundPos.visible) return;

            // 3D Coverage Cone Line (Sat to Ground)
            if (this.showFootprints && groundPos.visible) {
                ctx.strokeStyle = 'rgba(0, 243, 255, 0.25)';
                ctx.lineWidth = 1;
                ctx.setLineDash([3, 3]);
                ctx.beginPath();
                ctx.moveTo(satPos.x, satPos.y);
                ctx.lineTo(groundPos.x, groundPos.y);
                ctx.stroke();
                ctx.setLineDash([]);

                // Ground Footprint Pulse Circle
                const radiusPx = (covRadiusKm / 40000) * this.width * 0.5;
                ctx.strokeStyle = 'rgba(0, 243, 255, 0.4)';
                ctx.beginPath();
                ctx.arc(groundPos.x, groundPos.y, radiusPx, 0, Math.PI * 2);
                ctx.stroke();
            }

            // Satellite Core Icon
            ctx.fillStyle = 'rgba(0, 243, 255, 0.4)';
            ctx.beginPath();
            ctx.arc(satPos.x, satPos.y, 8, 0, Math.PI * 2);
            ctx.fill();

            ctx.fillStyle = '#00f3ff';
            ctx.fillRect(satPos.x - 3, satPos.y - 3, 6, 6);

            ctx.fillStyle = '#ffffff';
            ctx.fillRect(satPos.x - 8, satPos.y - 1, 4, 2);
            ctx.fillRect(satPos.x + 4, satPos.y - 1, 4, 2);
        });
    }

    setupEvents() {
        window.addEventListener('resize', () => this.resize());

        // Mouse Drag Controls for 3D Globe Rotation
        this.canvas.addEventListener('mousedown', (e) => {
            this.isDragging = true;
            this.lastMouseX = e.clientX;
            this.lastMouseY = e.clientY;
        });

        window.addEventListener('mouseup', () => this.isDragging = false);

        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            if (this.isDragging && this.projectionMode === '3d') {
                const deltaX = e.clientX - this.lastMouseX;
                const deltaY = e.clientY - this.lastMouseY;

                this.cameraYaw += deltaX * 0.008;
                this.cameraPitch = Math.max(-1.2, Math.min(1.2, this.cameraPitch + deltaY * 0.008));

                this.lastMouseX = e.clientX;
                this.lastMouseY = e.clientY;
                return;
            }

            // Hover Hit Detection
            let found = null;
            for (let sat of this.satellites) {
                const p = this.latLonTo(sat.lat, sat.lon, sat.altKm);
                if (p.visible && Math.hypot(p.x - mouseX, p.y - mouseY) < 14) {
                    found = { type: 'sat', data: sat, x: mouseX, y: mouseY };
                    break;
                }
            }

            if (!found) {
                for (let sensor of this.sensors) {
                    const p = this.latLonTo(sensor.lat, sensor.lon, 0);
                    if (p.visible && Math.hypot(p.x - mouseX, p.y - mouseY) < 14) {
                        found = { type: 'sensor', data: sensor, x: mouseX, y: mouseY };
                        break;
                    }
                }
            }

            if (found) {
                this.hoveredObject = found;
                this.showTooltip(found);
            } else {
                this.hoveredObject = null;
                this.tooltip.classList.add('hidden');
            }
        });

        this.canvas.addEventListener('click', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            const mouseX = e.clientX - rect.left;
            const mouseY = e.clientY - rect.top;

            if (this.hoveredObject && this.hoveredObject.type === 'sensor') {
                this.selectedSensor = this.hoveredObject.data;
                if (this.onSensorSelected) this.onSensorSelected(this.selectedSensor);
                return;
            }

            // Click to Deploy Sensor
            let lat = 0, lon = 0;
            if (this.projectionMode === '2d') {
                const pt = this.xyToLatLon2D(mouseX, mouseY);
                lat = pt.lat;
                lon = pt.lon;
            } else {
                lat = parseFloat(((Math.random() * 80) - 40).toFixed(2));
                lon = parseFloat(((Math.random() * 360) - 180).toFixed(2));
            }

            const count = this.sensors.length + 1;
            const typeNames = { buoy: 'Ocean Wave Buoy', seismic: 'Seismic Array', rf: 'RF Radar' };

            const newSensor = {
                id: `${this.activeSensorMode.toUpperCase()}-NODE-${String(count).padStart(2, '0')}`,
                type: this.activeSensorMode,
                lat,
                lon,
                name: `Deployed ${typeNames[this.activeSensorMode]}`,
                freq: this.activeSensorMode === 'buoy' ? '0.22 Hz' : (this.activeSensorMode === 'seismic' ? '12.8 Hz' : '3.5 MHz'),
                amp: '1.2m'
            };

            this.sensors.push(newSensor);
            this.selectedSensor = newSensor;
            if (this.onSensorDeployed) this.onSensorDeployed(newSensor);
        });
    }

    latLonTo(lat, lon, altKm = 0) {
        return this.latLonToXY(lat, lon, altKm);
    }

    showTooltip(info) {
        const ttTitle = document.getElementById('tt-title');
        const ttLatLon = document.getElementById('tt-latlon');
        const ttAlt = document.getElementById('tt-alt');
        const ttLinks = document.getElementById('tt-links');
        const ttRadius = document.getElementById('tt-radius');

        if (info.type === 'sat') {
            const sat = info.data;
            const radKm = SatPhysics.getCoverageRadius(sat.altKm, this.beamAngleDeg);
            ttTitle.textContent = `${sat.id} (LEO Constellation)`;
            ttLatLon.textContent = `${sat.lat.toFixed(1)}°, ${sat.lon.toFixed(1)}°`;
            ttAlt.textContent = `${sat.altKm} km`;
            ttLinks.textContent = `${sat.connectedSensors} Active Nodes`;
            ttRadius.textContent = `${radKm.toFixed(0)} km`;
        } else {
            const s = info.data;
            ttTitle.textContent = `${s.id} [${s.type.toUpperCase()}]`;
            ttLatLon.textContent = `${s.lat}°, ${s.lon}°`;
            ttAlt.textContent = `Sea Surface / Terrestrial`;
            ttLinks.textContent = s.nearestSat ? `Linked to ${s.nearestSat.id}` : `Searching Sat Link...`;
            ttRadius.textContent = `N/A (Ground Node)`;
        }

        this.tooltip.style.left = `${Math.min(this.width - 180, info.x + 15)}px`;
        this.tooltip.style.top = `${Math.min(this.height - 100, info.y + 15)}px`;
        this.tooltip.classList.remove('hidden');
    }
}

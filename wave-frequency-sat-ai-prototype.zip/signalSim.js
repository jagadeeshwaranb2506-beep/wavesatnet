/**
 * WAVE-PULSE AI // Wave Signal Generator & Synthetic FFT Engine
 */
const SignalSim = (function () {
    let currentBand = 'vlf';
    let anomalyActive = false;
    let anomalyType = null;
    let anomalyTimer = 0;

    const BANDS = {
        vlf: { name: 'VLF Acoustic (0-100 Hz)', minFreq: 0.1, maxFreq: 100, unit: 'Hz' },
        hf: { name: 'Ocean Swell (0.05-5.0 Hz)', minFreq: 0.05, maxFreq: 5.0, unit: 'Hz' },
        rf: { name: 'RF Ionospheric Radar (1-10 MHz)', minFreq: 1.0, maxFreq: 10.0, unit: 'MHz' }
    };

    /**
     * Generate synthetic time-domain waveform data (128 sample points)
     */
    function getWaveform(timeSec) {
        const samples = [];
        const numSamples = 128;
        
        let baseFreq = 1.2;
        let noiseLevel = 0.15;
        let harmonicScale = 0.4;

        if (currentBand === 'vlf') {
            baseFreq = 15.0;
        } else if (currentBand === 'rf') {
            baseFreq = 4.5;
        }

        for (let i = 0; i < numSamples; i++) {
            const t = timeSec + i * 0.01;
            // Primary fundamental wave
            let y = Math.sin(2 * Math.PI * baseFreq * t * 0.2);
            // Secondary harmonic
            y += harmonicScale * Math.sin(2 * Math.PI * baseFreq * 2.3 * t * 0.2 + 0.5);

            // Inject Anomaly transient wave pulse if active
            if (anomalyActive) {
                if (anomalyType === 'tsunami') {
                    // Solitary high amplitude low frequency surge
                    const pulse = Math.exp(-Math.pow((i - 64) / 15, 2)) * 3.5;
                    y += pulse * Math.sin(2 * Math.PI * 0.3 * t);
                } else if (anomalyType === 'seismic') {
                    // High frequency chirp explosion
                    const chirp = Math.sin(2 * Math.PI * (baseFreq * 4) * t) * (Math.random() * 2.0);
                    y += chirp;
                } else if (anomalyType === 'jamming') {
                    // Full spectrum white noise saturation
                    y += (Math.random() - 0.5) * 4.0;
                }
            }

            // Background noise
            y += (Math.random() - 0.5) * noiseLevel;
            samples.push(y);
        }

        return samples;
    }

    /**
     * Compute FFT frequency magnitude spectrum (64 bins)
     */
    function getFFTSpectrum(timeSec) {
        const numBins = 64;
        const spectrum = new Float32Array(numBins);
        
        const bandInfo = BANDS[currentBand];
        const stepFreq = (bandInfo.maxFreq - bandInfo.minFreq) / numBins;

        for (let i = 0; i < numBins; i++) {
            const freq = bandInfo.minFreq + i * stepFreq;
            // Natural 1/f spectral roll-off background noise
            let mag = 0.15 / (1 + i * 0.05) + Math.random() * 0.08;

            // Dominant ambient peak
            if (i === 12 || i === 13) {
                mag += 0.6 + Math.sin(timeSec * 2) * 0.15;
            } else if (i === 28) {
                mag += 0.35 + Math.cos(timeSec * 3) * 0.1;
            }

            // Anomaly Spectral Injections
            if (anomalyActive) {
                if (anomalyType === 'tsunami') {
                    // Massive low-frequency spike (Bins 2-8)
                    if (i >= 2 && i <= 8) {
                        mag += 1.8 * Math.sin((i / 8) * Math.PI) + (Math.random() * 0.2);
                    }
                } else if (anomalyType === 'seismic') {
                    // Mid-to-high frequency harmonic burst (Bins 35-52)
                    if (i >= 35 && i <= 52) {
                        mag += 1.4 + (Math.random() * 0.4);
                    }
                } else if (anomalyType === 'jamming') {
                    // Broadband high amplitude noise
                    mag += 0.8 + Math.random() * 0.9;
                }
            }

            spectrum[i] = Math.max(0, Math.min(2.5, mag));
        }

        return spectrum;
    }

    /**
     * Trigger a specific test wave anomaly
     */
    function triggerAnomaly(type = 'tsunami') {
        anomalyActive = true;
        anomalyType = type;
        anomalyTimer = 8.0; // Seconds active
    }

    function update(dt) {
        if (anomalyActive) {
            anomalyTimer -= dt;
            if (anomalyTimer <= 0) {
                anomalyActive = false;
                anomalyType = null;
            }
        }
    }

    function setBand(bandKey) {
        if (BANDS[bandKey]) {
            currentBand = bandKey;
        }
    }

    function getBand() {
        return BANDS[currentBand];
    }

    function isAnomalyActive() {
        return anomalyActive;
    }

    function getAnomalyType() {
        return anomalyType;
    }

    return {
        getWaveform,
        getFFTSpectrum,
        triggerAnomaly,
        update,
        setBand,
        getBand,
        isAnomalyActive,
        getAnomalyType
    };
})();

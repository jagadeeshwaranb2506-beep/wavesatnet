/**
 * WAVE-PULSE AI // Neural Signal Classifier & Threat Detection Engine
 */
const AIClassifier = (function () {

    /**
     * Analyze FFT spectrum array and return AI classification results
     * @param {Float32Array} spectrum FFT magnitude array
     * @param {boolean} isAnomaly Synthetic anomaly override
     * @param {string} anomalyType Specific anomaly type if forced
     */
    function classifySpectrum(spectrum, isAnomaly, anomalyType) {
        let totalEnergy = 0;
        let peakEnergy = 0;
        let peakBin = 0;

        for (let i = 0; i < spectrum.length; i++) {
            const mag = spectrum[i];
            totalEnergy += mag;
            if (mag > peakEnergy) {
                peakEnergy = mag;
                peakBin = i;
            }
        }

        const avgEnergy = totalEnergy / spectrum.length;

        // Spectral Entropy Calculation
        let entropy = 0;
        for (let i = 0; i < spectrum.length; i++) {
            const p = (spectrum[i] + 1e-6) / (totalEnergy + 1e-6);
            entropy -= p * Math.log2(p);
        }

        let classification = "NORMAL OCEAN SWELL";
        let confidence = 0.94 + Math.random() * 0.05;
        let severity = 0.12 + avgEnergy * 0.1;
        let statusBadge = "NOMINAL MONITORING";
        let statusClass = "status-normal";

        if (isAnomaly || peakEnergy > 1.2 || avgEnergy > 0.5) {
            if (anomalyType === 'tsunami' || (peakBin < 10 && peakEnergy > 1.2)) {
                classification = "ROGUE TSUNAMI SWELL ANOMALY";
                confidence = 0.982;
                severity = 0.88;
                statusBadge = "CRITICAL WAVE ALERT";
                statusClass = "status-warning";
            } else if (anomalyType === 'seismic' || (peakBin > 30 && peakEnergy > 1.1)) {
                classification = "SUBMARINE SEISMIC MICROSEISM";
                confidence = 0.965;
                severity = 0.74;
                statusBadge = "SEISMIC ANOMALY DETECTED";
                statusClass = "status-warning";
            } else if (anomalyType === 'jamming' || entropy > 5.2) {
                classification = "SATELLITE RF BROADBAND JAMMING";
                confidence = 0.991;
                severity = 0.95;
                statusBadge = "RF INTERFERENCE ALERT";
                statusClass = "status-warning";
            }
        }

        return {
            classification,
            confidence: (confidence * 100).toFixed(1) + "%",
            severityVal: severity.toFixed(2),
            severityPct: Math.min(100, Math.round(severity * 100)) + "%",
            statusBadge,
            statusClass,
            features: {
                peakSpectralEnergy: Math.min(100, Math.round((peakEnergy / 2.0) * 100)),
                harmonicEntropy: Math.min(100, Math.round((entropy / 6.0) * 100)),
                dopplerShift: Math.min(100, Math.round(30 + Math.random() * 50))
            }
        };
    }

    return {
        classifySpectrum
    };
})();
